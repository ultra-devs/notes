document.addEventListener("DOMContentLoaded", () => {
    promptLogin();
    loadHomeTab();
    setupEventListeners();
  });

  function promptLogin()
  {

    $('#settingsModal').modal('show');

    // Event listener for security type dropdown
    const securityTypeSelect = document.getElementById("securityTypeSelect");
    const tokenInputField = document.getElementById("tokenInputField");
    const passwordInputField = document.getElementById("passwordInputField");
  
    securityTypeSelect.addEventListener("change", () => {
      const selectedValue = securityTypeSelect.value;
  
      // Show/Hide fields based on security type
      if (selectedValue === "token") {
        tokenInputField.classList.remove("d-none");
        passwordInputField.classList.add("d-none");
      } else if (selectedValue === "session") {
        passwordInputField.classList.remove("d-none");
        tokenInputField.classList.add("d-none");
      }
    });
  
    // Event listener for Save Settings button
    document.getElementById("saveSettings").addEventListener("click", () => {
      const environment = document.getElementById("environmentSelect").value;
      const securityType = securityTypeSelect.value;
      const token = document.getElementById("tokenInput").value;
      const password = document.getElementById("passwordInput").value;
  
      if (!environment || !securityType || (!token && !password)) {
        alert("Please fill out all required fields.");
        return;
      }
  
      // Save settings logic here
      console.log("Environment:", environment);
      console.log("Security Type:", securityType);
      console.log("Token:", token);
      console.log("Password:", password);
  
      // Hide the modal
      $('#settingsModal').modal('hide');
    });


  }
  
  function setupEventListeners() {
    document.querySelector("#home-tab").addEventListener("click", loadHomeTab);
    document.querySelector("#execution-tab").addEventListener("click", loadExecutionTab);
    document.querySelector("#results-tab").addEventListener("click", loadResultsTab);
  }
  
  function loadHomeTab() {
    loadTabContent("#home", "js/home.js", "css/home.css");
  }
  
  function loadExecutionTab() {
    loadTabContent("#execution", "js/execution.js", "css/execution.css");
  }
  
  function loadResultsTab() {
    loadTabContent("#results", "js/results.js", "css/results.css");
  }
  
  function loadTabContent(tabId, jsFile, cssFile) {
    const tab = document.querySelector(tabId);
    tab.innerHTML = ""; // Clear existing content
    const script = document.createElement("script");
    script.src = jsFile;
    script.type = "text/javascript";
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = cssFile;
  
    document.head.appendChild(link);
    tab.appendChild(script);
  }
  