document.querySelector("#home").innerHTML = `
  <h3>Test Source</h3>
  <div class="accordion" id="infoPanelAccordion">
    <div class="card">
      <div class="card-header" id="infoHeading">
        <h5 class="mb-0">
          <button class="btn btn-link text-white d-flex align-items-center justify-content-between w-100" type="button" data-toggle="collapse" data-target="#infoPanel" aria-expanded="true" aria-controls="infoPanel">
            <span><i class="fas fa-info-circle"></i> Info Panel</span>
            <i class="fas fa-chevron-up toggle-icon"></i>
          </button>
        </h5>
      </div>
      <div id="infoPanel" class="collapse show" aria-labelledby="infoHeading" data-parent="#infoPanelAccordion">
        <div class="card-body">
          <p>This panel contains additional information or instructions for using the Dev Tool.</p>
        </div>
      </div>
    </div>
  </div>
  <div class="accordion mt-3" id="testSourceAccordion">
    <div class="card">
      <div class="card-header" id="headingOne">
        <h5 class="mb-0">
          <button class="btn btn-link text-white d-flex align-items-center justify-content-between w-100" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
            <span><i class="fas fa-box"></i> Test Box 1</span>
            <i class="fas fa-chevron-up toggle-icon"></i>
          </button>
        </h5>
      </div>
      <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#testSourceAccordion">
        <div class="card-body">
          <input type="text" class="form-control" placeholder="Test Box 1">
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header" id="headingTwo">
        <h5 class="mb-0">
          <button class="btn btn-link text-white d-flex align-items-center justify-content-between w-100" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
            <span><i class="fas fa-box"></i> Test Box 2</span>
            <i class="fas fa-chevron-down toggle-icon"></i>
          </button>
        </h5>
      </div>
      <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#testSourceAccordion">
        <div class="card-body">
          <input type="text" class="form-control" placeholder="Test Box 2">
        </div>
      </div>
    </div>
  </div>
`;
